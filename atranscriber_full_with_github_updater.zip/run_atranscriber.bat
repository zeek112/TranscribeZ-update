@echo off
setlocal
title atranscriber

if not exist venv\Scripts\activate.bat (
    echo Virtual environment not found.
    echo Run WINDOWS_SETUP\setup_windows.bat first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python gui_app.py
pause
endlocal
