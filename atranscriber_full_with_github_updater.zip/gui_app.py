import os
import shutil
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk

try:
    from tkinterdnd2 import DND_FILES
    DND_AVAILABLE = True
except Exception:
    DND_FILES = None
    DND_AVAILABLE = False

from modules.settings_manager import load_settings, save_settings, PRESETS
from modules.transcriber import process_file
from modules.queue_manager import find_media_files
from modules.diagnostics import ensure_folders
from modules.transcript_editor import TranscriptEditor
from modules.updater import check_for_updates
from modules.delivery_presets import DELIVERY_PRESETS, preset_text
from modules.fiverr_package import create_fiverr_delivery_zip
from modules.health_checker import health_report_text
from modules.improvement_center import recommendations_text
from modules.learning_dictionary import dictionary_text
from modules.client_packager import create_client_package
from modules.update_channels import load_channel, save_channel
from modules.model_recommender import recommend_model


APP_NAME = "atranscriber"
FOLDERS = ["input", "output", "completed", "failed", "logs", "history", "checkpoints"]


class ATranscriberGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        ensure_folders(FOLDERS)

        self.settings = load_settings()
        self.selected_files = []
        self.last_transcript_text = ""
        self.last_output_folder = None

        self.job_start_time = None
        self.current_progress_value = 0.0
        self.timer_running = False

        self.open_output_after_done_var = tk.BooleanVar(value=True)
        self.close_after_done_var = tk.BooleanVar(value=False)
        self.clear_input_after_done_var = tk.BooleanVar(value=False)
        self.delivery_preset_var = tk.StringVar(value="Meeting")

        self.title(APP_NAME)
        self.geometry("1060x900")
        self.minsize(980, 780)

        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        self.build_layout()
        self.load_settings_into_ui()

        try:
            self.setup_drag_drop()
        except Exception as e:
            self.log(f"Drag-and-drop disabled: {e}")
            self.log("Use Add Files or Add Folder instead.")

    def setup_drag_drop(self):
        if not DND_AVAILABLE:
            self.log("Drag-and-drop not installed or not compatible.")
            self.log("Use Add Files or Add Folder instead.")
            return
        try:
            self.drop_target_register(DND_FILES)
            self.dnd_bind("<<Drop>>", self.handle_drop)
            self.log("Drag-and-drop enabled.")
        except Exception as e:
            self.log(f"Drag-and-drop disabled: {e}")
            self.log("Use Add Files or Add Folder instead.")

    def handle_drop(self, event):
        try:
            paths = self.tk.splitlist(event.data)
        except Exception:
            paths = [event.data]
        for path in paths:
            path = path.strip("{}")
            if os.path.isfile(path):
                if path not in self.selected_files:
                    self.selected_files.append(path)
            elif os.path.isdir(path):
                self.add_folder_path(path)
        self.refresh_file_list()

    def build_layout(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(7, weight=1)
        self.build_header()
        self.build_input_section()
        self.build_output_section()
        self.build_settings_section()
        self.build_speaker_section()
        self.build_start_section()
        self.build_qol_section()
        self.build_status_section()

    def step_badge(self, parent, number, color="#2563eb"):
        return ctk.CTkLabel(
            parent, text=str(number), width=36, height=36, corner_radius=18,
            fg_color=color, text_color="white", font=ctk.CTkFont(size=18, weight="bold")
        )

    def build_header(self):
        header = ctk.CTkFrame(self)
        header.grid(row=0, column=0, padx=16, pady=(16, 8), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text="atranscriber", font=ctk.CTkFont(size=32, weight="bold")).grid(row=0, column=0, sticky="w", padx=16, pady=(14, 2))
        ctk.CTkLabel(header, text="Local transcription with client-ready exports, speaker names, AI notes, timer, ETA, and organized output.", font=ctk.CTkFont(size=14)).grid(row=1, column=0, sticky="w", padx=16, pady=(0, 14))

    def build_input_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=1, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, 1).grid(row=0, column=0, padx=14, pady=10)
        info = ctk.CTkFrame(frame, fg_color="transparent")
        info.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        info.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(info, text="Input files", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, sticky="w")
        self.input_summary = ctk.CTkLabel(info, text="No files selected yet. Add files, add a folder, or drag files here.", anchor="w")
        self.input_summary.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        buttons = ctk.CTkFrame(frame, fg_color="transparent")
        buttons.grid(row=0, column=2, padx=10, pady=8, sticky="e")
        ctk.CTkButton(buttons, text="Add Files", width=110, command=self.add_files).grid(row=0, column=0, padx=4)
        ctk.CTkButton(buttons, text="Add Folder", width=110, command=self.add_folder).grid(row=0, column=1, padx=4)
        ctk.CTkButton(buttons, text="Clear", width=80, fg_color="gray", command=self.clear_files).grid(row=0, column=2, padx=4)

    def build_output_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=2, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, 2).grid(row=0, column=0, padx=14, pady=10)
        middle = ctk.CTkFrame(frame, fg_color="transparent")
        middle.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        middle.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(middle, text="Output location", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, columnspan=2, sticky="w")
        ctk.CTkLabel(middle, text="Client / Project:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        self.client_var = tk.StringVar()
        self.client_entry = ctk.CTkEntry(middle, textvariable=self.client_var)
        self.client_entry.grid(row=1, column=1, padx=(10, 0), pady=(8, 0), sticky="ew")
        self.output_summary = ctk.CTkLabel(middle, text="Output path: output/Client/today/file_name/", anchor="w")
        self.output_summary.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        buttons = ctk.CTkFrame(frame, fg_color="transparent")
        buttons.grid(row=0, column=2, padx=10, pady=8, sticky="e")
        ctk.CTkButton(buttons, text="Open Output", width=120, command=lambda: self.open_folder("output")).grid(row=0, column=0, padx=4)
        ctk.CTkButton(buttons, text="Open Input", width=110, command=lambda: self.open_folder("input")).grid(row=0, column=1, padx=4)

    def build_settings_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=3, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, 3).grid(row=0, column=0, padx=14, pady=10)
        settings_area = ctk.CTkFrame(frame, fg_color="transparent")
        settings_area.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        settings_area.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkLabel(settings_area, text="Preset and options", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        self.preset_var = tk.StringVar()
        self.language_var = tk.StringVar()
        self.ollama_var = tk.StringVar()
        ctk.CTkLabel(settings_area, text="Preset").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ctk.CTkOptionMenu(settings_area, values=[preset["name"] for preset in PRESETS.values()], variable=self.preset_var, command=self.apply_preset_from_name).grid(row=2, column=0, padx=(0, 8), pady=(2, 8), sticky="ew")
        ctk.CTkLabel(settings_area, text="Language").grid(row=1, column=1, sticky="w", pady=(8, 0))
        ctk.CTkEntry(settings_area, textvariable=self.language_var).grid(row=2, column=1, padx=8, pady=(2, 8), sticky="ew")
        ctk.CTkLabel(settings_area, text="AI Model").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ctk.CTkEntry(settings_area, textvariable=self.ollama_var).grid(row=2, column=2, padx=(8, 0), pady=(2, 8), sticky="ew")
        ctk.CTkLabel(settings_area, text="Delivery Type").grid(row=4, column=0, sticky="w", pady=(8, 0))
        ctk.CTkOptionMenu(settings_area, values=list(DELIVERY_PRESETS.keys()), variable=self.delivery_preset_var).grid(row=5, column=0, padx=(0, 8), pady=(2, 8), sticky="ew")
        ctk.CTkButton(settings_area, text="View Presets", command=self.show_delivery_presets).grid(row=5, column=1, padx=8, pady=(2, 8), sticky="ew")
        self.gpu_var = tk.BooleanVar()
        self.ai_var = tk.BooleanVar()
        self.grammar_var = tk.BooleanVar()
        self.diarization_var = tk.BooleanVar()
        self.speaker_editor_var = tk.BooleanVar()
        self.keep_wav_var = tk.BooleanVar()
        options = ctk.CTkFrame(settings_area)
        options.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        options.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkCheckBox(options, text="AI Notes", variable=self.ai_var).grid(row=0, column=0, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(options, text="Speaker Labels", variable=self.diarization_var).grid(row=0, column=1, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(options, text="Grammar Cleanup", variable=self.grammar_var).grid(row=0, column=2, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(options, text="GPU Mode", variable=self.gpu_var).grid(row=1, column=0, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(options, text="Use Speaker Names Below", variable=self.speaker_editor_var).grid(row=1, column=1, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(options, text="Keep Clean WAV", variable=self.keep_wav_var).grid(row=1, column=2, padx=8, pady=8, sticky="w")
        ctk.CTkButton(frame, text="Save Settings", width=130, command=self.save_current_settings).grid(row=0, column=2, padx=14, pady=10, sticky="e")

    def build_speaker_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=4, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, "S", "#7c3aed").grid(row=0, column=0, padx=14, pady=10)
        area = ctk.CTkFrame(frame, fg_color="transparent")
        area.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        area.grid_columnconfigure((0, 1, 2, 3), weight=1)
        ctk.CTkLabel(area, text="Speaker names optional", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, columnspan=4, sticky="w")
        ctk.CTkLabel(area, text="If known, enter names before starting. Detected speakers are renamed in order.").grid(row=1, column=0, columnspan=4, sticky="w", pady=(2, 8))
        self.speaker_count_var = tk.StringVar(value="2")
        ctk.CTkLabel(area, text="Expected speakers").grid(row=2, column=0, sticky="w")
        ctk.CTkOptionMenu(area, values=["1", "2", "3", "4", "5", "6"], variable=self.speaker_count_var, command=lambda _: self.update_speaker_fields()).grid(row=3, column=0, padx=(0, 8), pady=(2, 4), sticky="ew")
        self.speaker_name_vars = []
        self.speaker_entries_frame = ctk.CTkFrame(area)
        self.speaker_entries_frame.grid(row=2, column=1, rowspan=2, columnspan=3, sticky="ew", padx=(8, 0))
        self.speaker_entries_frame.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkButton(frame, text="Clear Names", width=110, fg_color="gray", command=self.clear_speaker_names).grid(row=0, column=2, padx=14, pady=10)
        self.update_speaker_fields()

    def update_speaker_fields(self):
        for widget in self.speaker_entries_frame.winfo_children():
            widget.destroy()
        try:
            count = int(self.speaker_count_var.get())
        except Exception:
            count = 2
        old_values = [var.get() for var in getattr(self, "speaker_name_vars", [])]
        self.speaker_name_vars = []
        for i in range(count):
            var = tk.StringVar()
            if i < len(old_values):
                var.set(old_values[i])
            self.speaker_name_vars.append(var)
            ctk.CTkLabel(self.speaker_entries_frame, text=f"Speaker {i + 1}").grid(row=(i // 3) * 2, column=i % 3, sticky="w", padx=6, pady=(6, 0))
            ctk.CTkEntry(self.speaker_entries_frame, textvariable=var, placeholder_text=f"Guest {i + 1} name").grid(row=(i // 3) * 2 + 1, column=i % 3, sticky="ew", padx=6, pady=(0, 6))

    def clear_speaker_names(self):
        for var in self.speaker_name_vars:
            var.set("")
        self.log("Speaker names cleared.")

    def build_start_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=5, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, 4, "#16a34a").grid(row=0, column=0, padx=14, pady=10)
        start_text = ctk.CTkFrame(frame, fg_color="transparent")
        start_text.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        start_text.grid_columnconfigure(0, weight=1)
        self.phase_label = ctk.CTkLabel(start_text, text="Ready to start", font=ctk.CTkFont(size=18, weight="bold"))
        self.phase_label.grid(row=0, column=0, sticky="w")
        self.detail_label = ctk.CTkLabel(start_text, text="Finished files will appear in the output folder.", anchor="w")
        self.detail_label.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.progress = ctk.CTkProgressBar(start_text)
        self.progress.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        self.progress.set(0)
        timer_frame = ctk.CTkFrame(start_text, fg_color="transparent")
        timer_frame.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        timer_frame.grid_columnconfigure((0, 1, 2), weight=1)
        self.elapsed_label = ctk.CTkLabel(timer_frame, text="Elapsed: 00:00")
        self.elapsed_label.grid(row=0, column=0, sticky="w")
        self.eta_label = ctk.CTkLabel(timer_frame, text="ETA: --:--")
        self.eta_label.grid(row=0, column=1)
        self.percent_label = ctk.CTkLabel(timer_frame, text="Progress: 0%")
        self.percent_label.grid(row=0, column=2, sticky="e")
        self.start_button = ctk.CTkButton(frame, text="Start Transcription", command=self.start_processing_thread, height=44, width=180, fg_color="#16a34a", hover_color="#15803d")
        self.start_button.grid(row=0, column=2, padx=14, pady=10, sticky="e")

    def build_qol_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=6, column=0, padx=16, pady=5, sticky="ew")
        frame.grid_columnconfigure(1, weight=1)
        self.step_badge(frame, "Q", "#0f766e").grid(row=0, column=0, padx=14, pady=10)
        area = ctk.CTkFrame(frame, fg_color="transparent")
        area.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="ew")
        area.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkLabel(area, text="Quality-of-life options", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ctk.CTkCheckBox(area, text="Open output folder when done", variable=self.open_output_after_done_var).grid(row=1, column=0, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(area, text="Close app when done", variable=self.close_after_done_var).grid(row=1, column=1, padx=8, pady=8, sticky="w")
        ctk.CTkCheckBox(area, text="Clear selected file list when done", variable=self.clear_input_after_done_var).grid(row=1, column=2, padx=8, pady=8, sticky="w")
        buttons = ctk.CTkFrame(frame, fg_color="transparent")
        buttons.grid(row=0, column=2, padx=14, pady=10, sticky="e")
        ctk.CTkButton(buttons, text="Open Last Output", width=135, command=self.open_last_output_folder).grid(row=0, column=0, padx=4)
        ctk.CTkButton(buttons, text="Quit", width=80, fg_color="#991b1b", hover_color="#7f1d1d", command=self.quit_app).grid(row=0, column=1, padx=4)

        tool_buttons = ctk.CTkFrame(area, fg_color="transparent")
        tool_buttons.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        tool_buttons.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)

        ctk.CTkButton(tool_buttons, text="Health Check", command=self.show_health_check).grid(row=0, column=0, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="AI Improvement Center", command=self.show_improvement_center).grid(row=0, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="Learning Dictionary", command=self.show_learning_dictionary).grid(row=0, column=2, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="Recommend Model", command=self.show_model_recommendation).grid(row=0, column=3, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="Create Client ZIP", command=self.create_client_zip).grid(row=0, column=4, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="Check for Updates", command=self.check_updates_gui).grid(row=3, column=0, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(tool_buttons, text="Create Fiverr Delivery ZIP", command=self.create_fiverr_zip).grid(row=1, column=0, columnspan=2, padx=4, pady=4, sticky="ew")

    def build_status_section(self):
        frame = ctk.CTkFrame(self)
        frame.grid(row=7, column=0, padx=16, pady=(5, 16), sticky="nsew")
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(1, weight=1)
        top = ctk.CTkFrame(frame, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 4))
        top.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(top, text="Status / Log", font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(top, text="Open Transcript Editor", width=170, command=self.open_transcript_editor).grid(row=0, column=1, sticky="e")
        self.textbox = ctk.CTkTextbox(frame)
        self.textbox.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="nsew")

    def format_seconds(self, seconds):
        try:
            seconds = max(0, int(seconds))
        except Exception:
            return "--:--"
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    def start_timer(self):
        self.job_start_time = time.time()
        self.current_progress_value = 0.0
        self.timer_running = True
        self.update_timer_labels()

    def stop_timer(self):
        self.timer_running = False
        self.update_timer_labels(final=True)

    def update_timer_labels(self, final=False):
        if not self.job_start_time:
            return
        elapsed = time.time() - self.job_start_time
        progress = max(0.0, min(1.0, float(self.current_progress_value)))
        self.elapsed_label.configure(text=f"Elapsed: {self.format_seconds(elapsed)}")
        self.percent_label.configure(text=f"Progress: {int(progress * 100)}%")
        if progress > 0.03 and not final:
            estimated_total = elapsed / progress
            remaining = estimated_total - elapsed
            self.eta_label.configure(text=f"ETA: {self.format_seconds(remaining)}")
        elif final:
            self.eta_label.configure(text="ETA: 00:00")
        else:
            self.eta_label.configure(text="ETA: calculating...")
        if self.timer_running:
            self.after(1000, self.update_timer_labels)

    def load_settings_into_ui(self):
        self.client_var.set(self.settings.get("client_name", "General"))
        self.language_var.set(self.settings.get("language", "en"))
        self.ollama_var.set(self.settings.get("ollama_model", "llama3.2"))
        self.preset_var.set(self.settings.get("preset", "Client Ready"))
        self.gpu_var.set(self.settings.get("use_gpu", False))
        self.ai_var.set(self.settings.get("use_ai", True))
        self.grammar_var.set(self.settings.get("use_grammar", True))
        self.diarization_var.set(self.settings.get("use_diarization", True))
        self.speaker_editor_var.set(self.settings.get("use_speaker_editor", True))
        self.keep_wav_var.set(self.settings.get("keep_wav", False))
        self.open_output_after_done_var.set(self.settings.get("open_output_after_done", True))
        self.close_after_done_var.set(self.settings.get("close_after_done", False))
        self.clear_input_after_done_var.set(self.settings.get("clear_input_after_done", False))
        self.delivery_preset_var.set(self.settings.get("delivery_preset", "Meeting"))
        saved_names = self.settings.get("speaker_names", [])
        if saved_names:
            count = max(1, min(6, len(saved_names)))
            self.speaker_count_var.set(str(count))
            self.update_speaker_fields()
            for i, name in enumerate(saved_names[:count]):
                self.speaker_name_vars[i].set(name)
        self.update_output_summary()

    def apply_preset_from_name(self, preset_name):
        for preset in PRESETS.values():
            if preset["name"] == preset_name:
                self.settings["preset"] = preset["name"]
                self.settings["model"] = preset["model"]
                self.settings["use_grammar"] = preset["grammar"]
                self.settings["use_ai"] = preset["ai"]
                self.settings["use_diarization"] = preset["diarization"]
                self.settings["template"] = preset["template"]
                self.grammar_var.set(preset["grammar"])
                self.ai_var.set(preset["ai"])
                self.diarization_var.set(preset["diarization"])
                self.log(f"Preset applied: {preset_name}")
                return

    def get_speaker_names(self):
        return [var.get().strip() for var in self.speaker_name_vars]

    def get_current_settings(self):
        settings = self.settings.copy()
        settings.update({
            "client_name": self.client_var.get().strip() or "General",
            "preset": self.preset_var.get(),
            "language": self.language_var.get().strip() or "en",
            "ollama_model": self.ollama_var.get().strip() or "llama3.2",
            "use_gpu": self.gpu_var.get(),
            "use_ai": self.ai_var.get(),
            "use_grammar": self.grammar_var.get(),
            "use_diarization": self.diarization_var.get(),
            "use_speaker_editor": self.speaker_editor_var.get(),
            "keep_wav": self.keep_wav_var.get(),
            "speaker_names": self.get_speaker_names(),
            "open_output_after_done": self.open_output_after_done_var.get(),
            "close_after_done": self.close_after_done_var.get(),
            "clear_input_after_done": self.clear_input_after_done_var.get(),
            "delivery_preset": self.delivery_preset_var.get()
        })
        return settings

    def save_current_settings(self):
        self.settings = self.get_current_settings()
        save_settings(self.settings)
        self.update_output_summary()
        self.log("Settings saved.")

    def update_output_summary(self):
        client = self.client_var.get().strip() or "General"
        self.output_summary.configure(text=f"Output path: output/{client}/today/file_name/")

    def add_files(self):
        paths = filedialog.askopenfilenames(title="Select audio/video files", filetypes=[("Media files", "*.mp3 *.wav *.m4a *.mp4 *.mov"), ("All files", "*.*")])
        for path in paths:
            if path not in self.selected_files:
                self.selected_files.append(path)
        self.refresh_file_list()

    def add_folder(self):
        folder = filedialog.askdirectory(title="Select folder with media files")
        if folder:
            self.add_folder_path(folder)
            self.refresh_file_list()

    def add_folder_path(self, folder):
        supported = (".mp3", ".wav", ".m4a", ".mp4", ".mov")
        for root, dirs, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(supported):
                    path = os.path.join(root, file)
                    if path not in self.selected_files:
                        self.selected_files.append(path)

    def clear_files(self):
        self.selected_files = []
        self.refresh_file_list()

    def refresh_file_list(self):
        count = len(self.selected_files)
        if count == 0:
            self.input_summary.configure(text="No files selected yet. Add audio/video files or choose a folder.")
            self.textbox.delete("1.0", "end")
            self.log("No files selected.")
            return
        self.input_summary.configure(text=f"{count} file(s) selected and ready.")
        self.textbox.delete("1.0", "end")
        self.log("Selected files:")
        for path in self.selected_files:
            self.log(f"- {os.path.basename(path)}")

    def copy_selected_files_to_input(self):
        os.makedirs("input", exist_ok=True)
        for src in self.selected_files:
            filename = os.path.basename(src)
            dest = os.path.join("input", filename)
            counter = 1
            base, ext = os.path.splitext(filename)
            while os.path.exists(dest):
                dest = os.path.join("input", f"{base}_{counter}{ext}")
                counter += 1
            shutil.copy2(src, dest)

    def start_processing_thread(self):
        thread = threading.Thread(target=self.start_processing, daemon=True)
        thread.start()

    def update_status(self, message):
        self.phase_label.configure(text=message[:60])
        self.detail_label.configure(text=message)
        self.log(message)

    def start_processing(self):
        try:
            self.start_button.configure(state="disabled")
            self.progress.set(0)
            self.current_progress_value = 0.0
            self.elapsed_label.configure(text="Elapsed: 00:00")
            self.eta_label.configure(text="ETA: calculating...")
            self.percent_label.configure(text="Progress: 0%")
            self.start_timer()
            self.save_current_settings()

            if self.selected_files:
                self.log("Copying selected files to input folder...")
                self.copy_selected_files_to_input()

            files = find_media_files("input")
            if not files:
                self.log("No files found. Add files first.")
                messagebox.showwarning(APP_NAME, "No files found. Add files first.")
                self.stop_timer()
                return

            total = len(files)
            self.log(f"Starting {total} job(s)...")

            for index, file_path in enumerate(files, start=1):
                self.log("")
                self.log(f"Processing {index}/{total}: {os.path.basename(file_path)}")

                def combined_progress(job_value):
                    overall = ((index - 1) + job_value) / total
                    self.current_progress_value = overall
                    self.progress.set(overall)

                result = process_file(file_path, self.settings, status_callback=self.update_status, progress_callback=combined_progress)
                self.log(f"Finished {index}/{total}")

                if result and result.get("output_folder"):
                    self.last_output_folder = result.get("client_ready_folder") or result["output_folder"]
                    self.load_last_transcript(result["output_folder"])

            self.current_progress_value = 1.0
            self.progress.set(1)
            self.phase_label.configure(text="All jobs finished")
            self.detail_label.configure(text="Open the output folder to view files.")
            self.stop_timer()
            self.handle_completion_actions()

        except Exception as e:
            self.log(f"ERROR: {e}")
            self.stop_timer()
            messagebox.showerror(APP_NAME, str(e))
        finally:
            self.start_button.configure(state="normal")

    def handle_completion_actions(self):
        messagebox.showinfo(APP_NAME, "All transcription jobs finished.")
        if self.clear_input_after_done_var.get():
            self.selected_files = []
            self.refresh_file_list()
        if self.open_output_after_done_var.get():
            if self.last_output_folder and os.path.exists(self.last_output_folder):
                self.open_path(self.last_output_folder)
            else:
                self.open_folder("output")
        if self.close_after_done_var.get():
            self.after(750, self.quit_app)

    def load_last_transcript(self, output_folder):
        try:
            # Search normal and organized output folders
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if file.endswith("_transcript.txt"):
                        path = os.path.join(root, file)
                        with open(path, "r", encoding="utf-8") as f:
                            self.last_transcript_text = f.read()
                        return
        except Exception:
            pass

    def open_transcript_editor(self):
        if not self.last_transcript_text:
            messagebox.showinfo(APP_NAME, "No transcript loaded yet. Run a job first.")
            return
        TranscriptEditor(self, self.last_transcript_text)

    def open_last_output_folder(self):
        if self.last_output_folder and os.path.exists(self.last_output_folder):
            self.open_path(self.last_output_folder)
        else:
            messagebox.showinfo(APP_NAME, "No completed output folder yet.")


    def show_text_window(self, title, content):
        window = tk.Toplevel(self)
        window.title(title)
        window.geometry("900x650")
        text = tk.Text(window, wrap="word")
        text.pack(fill="both", expand=True, padx=10, pady=10)
        text.insert("1.0", content)

    def show_health_check(self):
        self.show_text_window("Dependency Health Check", health_report_text())

    def show_improvement_center(self):
        self.show_text_window("AI Improvement Center", recommendations_text())

    def show_learning_dictionary(self):
        self.show_text_window("Learning Dictionary", dictionary_text())

    def show_model_recommendation(self):
        names = self.get_speaker_names()
        speaker_count = max(1, len([n for n in names if n.strip()]) or int(self.speaker_count_var.get() or 1))
        rec = recommend_model(duration_seconds=0, speaker_count=speaker_count, use_gpu=self.gpu_var.get(), priority="balanced")
        msg = f"Recommended preset: {rec['preset']}\nRecommended model: {rec['model']}\n\nReason:\n{rec['reason']}"
        self.show_text_window("Smart Model Recommender", msg)


    def show_delivery_presets(self):
        self.show_text_window("Delivery Presets", preset_text())

    def create_fiverr_zip(self):
        if not self.last_output_folder:
            messagebox.showinfo(APP_NAME, "No completed job folder available yet.")
            return
        job_folder = self.last_output_folder
        if os.path.basename(job_folder) == "01_Client_Ready":
            job_folder = os.path.dirname(job_folder)
        package = create_fiverr_delivery_zip(job_folder)
        if package:
            messagebox.showinfo(APP_NAME, f"Fiverr delivery package created:\n{package}")
            self.open_folder("client_packages")
        else:
            messagebox.showerror(APP_NAME, "Could not create Fiverr delivery package.")

    def create_client_zip(self):
        if not self.last_output_folder:
            messagebox.showinfo(APP_NAME, "No client-ready folder available yet.")
            return
        package = create_client_package(self.last_output_folder)
        if package:
            messagebox.showinfo(APP_NAME, f"Client package created:\n{package}")
            self.open_folder("client_packages")
        else:
            messagebox.showerror(APP_NAME, "Could not create client package.")


    def check_updates_gui(self):
        result = check_for_updates()

        if not result.get("success"):
            messagebox.showerror(
                "Updater",
                f"Update check failed:\n{result.get('error', 'Unknown error')}"
            )
            return

        if result.get("update_available"):
            messagebox.showinfo(
                "Update Available",
                f"Current: {result.get('current_version')}\n"
                f"Latest: {result.get('latest_version')}\n"
                f"Channel: {result.get('channel')}\n\n"
                f"Notes:\n{result.get('notes')}\n\n"
                f"Download URL:\n{result.get('download_url')}"
            )
        else:
            messagebox.showinfo(
                "Updater",
                f"You are already up to date.\n\n"
                f"Current version: {result.get('current_version')}"
            )

    def open_path(self, path):
        if os.name == "nt":
            os.startfile(path)
        elif os.name == "posix":
            import subprocess
            if os.uname().sysname == "Darwin":
                subprocess.run(["open", path])
            else:
                subprocess.run(["xdg-open", path])

    def open_folder(self, folder):
        os.makedirs(folder, exist_ok=True)
        self.open_path(os.path.abspath(folder))

    def quit_app(self):
        try:
            self.timer_running = False
        except Exception:
            pass
        self.destroy()

    def log(self, message):
        self.textbox.insert("end", message + "\n")
        self.textbox.see("end")


if __name__ == "__main__":
    app = ATranscriberGUI()
    app.mainloop()
