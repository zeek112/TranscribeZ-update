import shutil
import sys
import importlib.util

def check_command(name, command):
    return name, shutil.which(command) is not None

def check_package(name, import_name):
    return name, importlib.util.find_spec(import_name) is not None

def main():
    checks = []
    print("atranscriber Windows Health Check")
    print("=================================")
    print(f"Python: {sys.version}")
    print()

    for name, cmd in [
        ("FFmpeg", "ffmpeg"),
        ("FFprobe", "ffprobe"),
        ("Java", "java"),
        ("Ollama", "ollama"),
    ]:
        checks.append(check_command(name, cmd))

    for name, imp in [
        ("CustomTkinter", "customtkinter"),
        ("Faster Whisper", "faster_whisper"),
        ("Pyannote", "pyannote.audio"),
        ("ReportLab", "reportlab"),
        ("Python DOCX", "docx"),
        ("LanguageTool", "language_tool_python"),
        ("TQDM", "tqdm"),
        ("PSUtil", "psutil"),
    ]:
        checks.append(check_package(name, imp))

    try:
        import torch
        checks.append(("NVIDIA CUDA GPU", bool(torch.cuda.is_available())))
    except Exception:
        checks.append(("NVIDIA CUDA GPU", False))

    passed = 0
    for name, ok in checks:
        print(f"{'OK' if ok else 'MISSING'}: {name}")
        passed += 1 if ok else 0

    print()
    print(f"Passed {passed}/{len(checks)} checks.")
    print()
    print("Notes:")
    print("- Missing FFmpeg means audio conversion will fail.")
    print("- Missing Ollama means AI notes will fail.")
    print("- Missing Java may affect grammar checking.")
    print("- Missing CUDA only affects GPU mode; CPU mode can still work.")

if __name__ == "__main__":
    main()
