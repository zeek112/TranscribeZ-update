def recommend_model(duration_seconds=0, speaker_count=1, use_gpu=False, priority="balanced"):
    """
    Returns a recommended preset/model based on basic job info.
    priority can be: speed, balanced, accuracy
    """
    duration_seconds = duration_seconds or 0
    speaker_count = speaker_count or 1

    if priority == "speed":
        return {
            "preset": "Fast Draft",
            "model": "base",
            "reason": "Speed priority selected. Base model is faster for quick draft transcripts."
        }

    if priority == "accuracy":
        if use_gpu:
            return {
                "preset": "Legal / Verbatim Style",
                "model": "medium",
                "reason": "Accuracy priority selected and GPU is enabled. Medium model gives better accuracy."
            }
        return {
            "preset": "Client Ready",
            "model": "small",
            "reason": "Accuracy priority selected but GPU may not be available. Small model balances accuracy and speed."
        }

    if duration_seconds < 600 and speaker_count <= 2:
        return {
            "preset": "Fast Draft",
            "model": "base",
            "reason": "Short file with few speakers. Fast Draft should be enough for quick turnaround."
        }

    if duration_seconds > 3600 or speaker_count >= 4:
        return {
            "preset": "Client Ready",
            "model": "small",
            "reason": "Longer or multi-speaker file. Client Ready provides better quality without being too slow."
        }

    return {
        "preset": "Client Ready",
        "model": "small",
        "reason": "Balanced recommendation for most customer jobs."
    }
