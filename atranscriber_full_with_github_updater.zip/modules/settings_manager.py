import json
import os

SETTINGS_FILE = "settings.json"

DEFAULT_SETTINGS = {
    "client_name": "General",
    "preset": "Client Ready",
    "model": "base",
    "language": "en",
    "use_gpu": False,
    "use_grammar": True,
    "use_ai": True,
    "use_diarization": True,
    "use_speaker_editor": True,
    "keep_wav": False,
    "ollama_model": "llama3.2",
    "template": "meeting",
    "speaker_names": [],
    "open_output_after_done": True,
    "close_after_done": False,
    "clear_input_after_done": False,
    "delivery_preset": "Meeting"
}

PRESETS = {
    "1": {"name": "Fast Draft", "model": "base", "grammar": False, "ai": False, "diarization": False, "template": "clean"},
    "2": {"name": "Client Ready", "model": "small", "grammar": True, "ai": True, "diarization": True, "template": "meeting"},
    "3": {"name": "Podcast Captions", "model": "small", "grammar": True, "ai": True, "diarization": True, "template": "podcast"},
    "4": {"name": "Meeting Notes", "model": "base", "grammar": True, "ai": True, "diarization": True, "template": "meeting"},
    "5": {"name": "Legal / Verbatim Style", "model": "medium", "grammar": False, "ai": True, "diarization": True, "template": "legal"},
    "6": {"name": "YouTube Captions", "model": "base", "grammar": True, "ai": True, "diarization": False, "template": "youtube"}
}

def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        return DEFAULT_SETTINGS.copy()
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as file:
            loaded = json.load(file)
        settings = DEFAULT_SETTINGS.copy()
        settings.update(loaded)
        return settings
    except Exception:
        return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as file:
        json.dump(settings, file, indent=4)
