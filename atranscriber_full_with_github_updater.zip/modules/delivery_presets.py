DELIVERY_PRESETS = {
    "Podcast": "Podcast transcript, captions, chapters, summary, highlights.",
    "YouTube": "YouTube captions, chapters, transcript, and summary.",
    "Meeting": "Meeting transcript, decisions, action items, executive summary.",
    "Interview": "Speaker-labeled transcript, timestamps, summary, review files.",
    "Legal Draft": "Verbatim-style draft, timestamps, review report. Human review required."
}

def preset_text():
    lines = ["Delivery Presets", "================", ""]
    for name, desc in DELIVERY_PRESETS.items():
        lines.append(f"{name}: {desc}")
    return "\n".join(lines)
