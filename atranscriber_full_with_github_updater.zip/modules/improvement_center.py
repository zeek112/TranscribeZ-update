import os
import sqlite3
from pathlib import Path
from modules.health_checker import run_health_check

DB_PATH = Path("history/jobs.db")

def analyze_job_history():
    suggestions = []

    if not DB_PATH.exists():
        suggestions.append({
            "title": "No job history yet",
            "detail": "Run a few transcription jobs before performance recommendations become useful.",
            "action": "Run jobs normally."
        })
        return suggestions

    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT status, model, device, duration, error FROM jobs ORDER BY id DESC LIMIT 50")
        rows = cur.fetchall()
        conn.close()
    except Exception as e:
        suggestions.append({
            "title": "Could not read job history",
            "detail": str(e),
            "action": "Check history/jobs.db."
        })
        return suggestions

    failed = [r for r in rows if r[0] != "completed"]
    gpu_jobs = [r for r in rows if "cuda" in str(r[2]).lower() or "gpu" in str(r[2]).lower()]
    ai_errors = [r for r in rows if "ollama" in str(r[4]).lower() or "ai generation failed" in str(r[4]).lower()]
    diarization_errors = [r for r in rows if "diarization" in str(r[4]).lower()]

    if failed:
        suggestions.append({
            "title": "Failed jobs detected",
            "detail": f"{len(failed)} recent job(s) failed.",
            "action": "Open logs/ and review the newest error report."
        })

    if not gpu_jobs:
        suggestions.append({
            "title": "GPU acceleration may not be active",
            "detail": "Recent jobs do not show CUDA/GPU usage.",
            "action": "Enable GPU Mode and verify CUDA PyTorch if using NVIDIA RTX."
        })

    if ai_errors:
        suggestions.append({
            "title": "AI notes may need attention",
            "detail": "Ollama or AI note generation errors were found.",
            "action": "Start Ollama and run `ollama pull llama3.2`."
        })

    if diarization_errors:
        suggestions.append({
            "title": "Speaker diarization errors found",
            "detail": "Speaker labeling failed in some recent jobs.",
            "action": "Run `hf auth login` and accept the required pyannote model pages."
        })

    if not suggestions:
        suggestions.append({
            "title": "No major issues found",
            "detail": "Recent jobs look healthy.",
            "action": "Continue using Client Ready preset for normal work."
        })

    return suggestions

def analyze_health():
    suggestions = []
    for name, ok, detail in run_health_check():
        if not ok:
            suggestions.append({
                "title": f"{name} needs attention",
                "detail": detail,
                "action": "Use the setup README or dependency repair instructions."
            })
    return suggestions

def get_improvement_recommendations():
    recs = []
    recs.extend(analyze_health())
    recs.extend(analyze_job_history())

    recs.append({
        "title": "Keep stable update channel for customer work",
        "detail": "Stable mode avoids experimental changes during paid jobs.",
        "action": "Use Stable unless testing new features."
    })

    return recs

def recommendations_text():
    recs = get_improvement_recommendations()
    lines = ["AI Improvement Center", "=====================", ""]
    for i, rec in enumerate(recs, start=1):
        lines.append(f"{i}. {rec['title']}")
        lines.append(f"   Detail: {rec['detail']}")
        lines.append(f"   Suggested action: {rec['action']}")
        lines.append("")
    return "\n".join(lines)
