import os
import sys
import shutil
import subprocess
import platform
from pathlib import Path

def command_exists(command):
    return shutil.which(command) is not None

def run_command(command):
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        return result.returncode == 0, (result.stdout or result.stderr).strip()
    except Exception as e:
        return False, str(e)

def check_python_package(import_name):
    try:
        __import__(import_name)
        return True
    except Exception:
        return False

def check_disk_space(path="."):
    try:
        usage = shutil.disk_usage(path)
        free_gb = usage.free / (1024 ** 3)
        return round(free_gb, 2)
    except Exception:
        return None

def check_gpu():
    try:
        import torch
        if torch.cuda.is_available():
            return True, torch.cuda.get_device_name(0)
        return False, "CUDA not available"
    except Exception:
        return False, "PyTorch not installed or unavailable"

def check_huggingface_login():
    token_path = Path.home() / ".cache" / "huggingface" / "token"
    return token_path.exists()

def run_health_check():
    checks = []

    checks.append(("Python", True, sys.version.split()[0]))
    checks.append(("Operating System", True, platform.platform()))

    for name, cmd in [
        ("FFmpeg", "ffmpeg"),
        ("FFprobe", "ffprobe"),
        ("Java", "java"),
        ("Ollama", "ollama"),
    ]:
        exists = command_exists(cmd)
        detail = "Found" if exists else "Missing"
        if exists:
            ok, output = run_command([cmd, "--version"] if cmd != "java" else [cmd, "-version"])
            detail = output.splitlines()[0] if output else "Found"
        checks.append((name, exists, detail))

    packages = [
        ("CustomTkinter", "customtkinter"),
        ("Faster Whisper", "faster_whisper"),
        ("Pyannote", "pyannote.audio"),
        ("Python DOCX", "docx"),
        ("ReportLab", "reportlab"),
        ("LanguageTool", "language_tool_python"),
        ("TQDM", "tqdm"),
        ("PSUtil", "psutil"),
    ]

    for label, import_name in packages:
        checks.append((label, check_python_package(import_name), "Installed" if check_python_package(import_name) else "Missing"))

    gpu_ok, gpu_detail = check_gpu()
    checks.append(("GPU / CUDA", gpu_ok, gpu_detail))

    hf_ok = check_huggingface_login()
    checks.append(("Hugging Face Login", hf_ok, "Token found" if hf_ok else "Not logged in"))

    free_gb = check_disk_space(".")
    checks.append(("Disk Space", free_gb is not None and free_gb > 5, f"{free_gb} GB free" if free_gb is not None else "Unknown"))

    return checks

def health_report_text():
    checks = run_health_check()
    lines = ["Dependency Health Check", "=======================", ""]
    for name, ok, detail in checks:
        mark = "OK" if ok else "MISSING / ISSUE"
        lines.append(f"{mark}: {name} - {detail}")

    lines.append("")
    lines.append("Suggested fixes:")
    lines.append("- Missing FFmpeg: install FFmpeg and add it to PATH.")
    lines.append("- Missing Ollama: install Ollama and run `ollama pull llama3.2`.")
    lines.append("- Missing Hugging Face login: run `hf auth login`.")
    lines.append("- GPU not found: install CUDA PyTorch on NVIDIA RTX systems.")
    lines.append("- Missing Python packages: run `pip install -r requirements.txt`.")
    return "\n".join(lines)
