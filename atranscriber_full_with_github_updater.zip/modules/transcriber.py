import os
import shutil
import subprocess
from datetime import datetime
from tqdm import tqdm
from faster_whisper import WhisperModel

try:
    import language_tool_python
    GRAMMAR_AVAILABLE = True
except Exception:
    GRAMMAR_AVAILABLE = False

from modules.gpu_tools import detect_gpu
from modules.diagnostics import write_history, save_error_report
from modules.exports import export_txt, export_srt, export_vtt, export_json, export_docx, quality_report, format_time_txt
from modules.pdf_export import export_pdf
from modules.audio_cleanup import clean_audio
from modules.database import add_job
from modules.ai_notes import export_ai_notes
from modules.diarization import run_diarization, best_speaker, auto_rename_speakers, speaker_name_editor
from modules.output_organizer import organize_job_output
from modules.chapters import export_chapters
from modules.branded_pdf import export_branded_pdf
from modules.delivery_readme import create_delivery_readme
from modules.confidence_scoring import write_confidence_report
from modules.learning_dictionary import apply_rules_to_text

def safe_filename(name):
    return "".join(c if c.isalnum() or c in " ._-()" else "_" for c in name).strip()

def get_duration(file_path):
    try:
        result = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", file_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return float(result.stdout.strip())
    except Exception:
        return 0

def clean_text(text, grammar_tool):
    if not grammar_tool:
        return text
    try:
        matches = grammar_tool.check(text)
        return language_tool_python.utils.correct(text, matches)
    except Exception:
        return text

def unique_path(folder, filename):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    counter = 1
    original = path
    while os.path.exists(path):
        root, ext = os.path.splitext(original)
        path = f"{root}_{counter}{ext}"
        counter += 1
    return path

def notify(callback, message):
    if callback:
        callback(message)
    else:
        print(message)

def apply_preentered_speaker_names(final_segments, speaker_names, status_callback=None):
    if not speaker_names:
        return final_segments
    speaker_order = []
    for segment in final_segments:
        speaker = segment.get("speaker") or "Guest"
        if speaker not in speaker_order:
            speaker_order.append(speaker)
    rename_map = {}
    for idx, speaker in enumerate(speaker_order):
        if idx < len(speaker_names):
            name = speaker_names[idx].strip()
            if name:
                rename_map[speaker] = name
    if not rename_map:
        return final_segments
    notify(status_callback, "Applying pre-entered speaker names...")
    for segment in final_segments:
        speaker = segment.get("speaker")
        if speaker in rename_map:
            segment["speaker"] = rename_map[speaker]
    return final_segments

def process_file(input_file, settings, status_callback=None, progress_callback=None):
    running_from_gui = status_callback is not None
    filename = os.path.basename(input_file)
    base_name = safe_filename(os.path.splitext(filename)[0])
    today = datetime.now().strftime("%Y-%m-%d")
    client_folder = os.path.join("output", safe_filename(settings["client_name"]), today)
    job_folder = os.path.join(client_folder, base_name)
    os.makedirs(job_folder, exist_ok=True)
    duration = get_duration(input_file)
    status = "failed"
    error = ""
    device_label = "gpu" if settings.get("use_gpu") else "cpu"
    organized_output = None

    try:
        notify(status_callback, f"PROCESSING: {filename}")
        notify(status_callback, f"Duration: {format_time_txt(duration)}")
        if progress_callback:
            progress_callback(0.05)
        clean_wav = os.path.join(job_folder, f"{base_name}_clean.wav")
        notify(status_callback, "Cleaning audio...")
        clean_audio(input_file, clean_wav)
        if progress_callback:
            progress_callback(0.15)
        device, compute_type = detect_gpu(settings["use_gpu"])
        device_label = device
        notify(status_callback, "Loading Whisper model...")
        model = WhisperModel(settings["model"], device=device, compute_type=compute_type)
        grammar_tool = None
        if settings["use_grammar"] and GRAMMAR_AVAILABLE:
            try:
                notify(status_callback, "Loading grammar checker...")
                grammar_tool = language_tool_python.LanguageTool("en-US")
            except Exception:
                grammar_tool = None
        notify(status_callback, "Transcribing...")
        segments, info = model.transcribe(clean_wav, beam_size=1, vad_filter=True, language=settings["language"])
        segments = list(segments)
        final_segments = []
        total_segments = max(len(segments), 1)
        for idx, segment in enumerate(tqdm(segments, desc="Transcribing", unit="segment", ncols=100), start=1):
            final_segments.append({"start": float(segment.start), "end": float(segment.end), "speaker": None, "text": apply_rules_to_text(clean_text(segment.text.strip(), grammar_tool), settings.get("client_name", "Global"))})
            if progress_callback:
                progress_callback(0.15 + (idx / total_segments) * 0.45)
        if settings["use_diarization"]:
            try:
                notify(status_callback, "Running speaker diarization...")
                speaker_segments = run_diarization(clean_wav)
                for segment in final_segments:
                    segment["speaker"] = best_speaker(segment["start"], segment["end"], speaker_segments)
                final_segments, speaker_map = auto_rename_speakers(final_segments)
                speaker_names = settings.get("speaker_names", [])
                final_segments = apply_preentered_speaker_names(final_segments, speaker_names, status_callback)
                if settings.get("use_speaker_editor") and not running_from_gui:
                    final_segments = speaker_name_editor(final_segments, speaker_map)
                elif settings.get("use_speaker_editor") and running_from_gui:
                    notify(status_callback, "Speaker names handled by GUI. No terminal prompt needed.")
            except Exception as diarization_error:
                notify(status_callback, f"Diarization failed: {diarization_error}")
        if progress_callback:
            progress_callback(0.70)
        for segment in final_segments:
            if not segment.get("speaker"):
                segment["speaker"] = "Guest"
        notify(status_callback, "Exporting files...")
        txt_path = os.path.join(job_folder, f"{base_name}_transcript.txt")
        srt_path = os.path.join(job_folder, f"{base_name}.srt")
        vtt_path = os.path.join(job_folder, f"{base_name}.vtt")
        json_path = os.path.join(job_folder, f"{base_name}.json")
        docx_path = os.path.join(job_folder, f"{base_name}_transcript.docx")
        pdf_path = os.path.join(job_folder, f"{base_name}_transcript.pdf")
        quality_path = os.path.join(job_folder, f"{base_name}_quality_report.txt")
        chapters_path = os.path.join(job_folder, f"{base_name}_chapters.txt")
        branded_pdf_path = os.path.join(job_folder, f"{base_name}_branded_transcript.pdf")
        confidence_path = os.path.join(job_folder, f"{base_name}_confidence_review.txt")
        export_txt(txt_path, final_segments)
        export_srt(srt_path, final_segments)
        export_vtt(vtt_path, final_segments)
        export_json(json_path, final_segments)
        export_docx(docx_path, base_name, final_segments, settings.get("template", "clean"))
        export_pdf(pdf_path, base_name, final_segments)
        export_branded_pdf(branded_pdf_path, base_name, settings.get('client_name', 'General'), settings.get('delivery_preset', 'Meeting'), final_segments)
        export_chapters(chapters_path, final_segments)
        quality_report(quality_path, filename, final_segments, duration)
        write_confidence_report(confidence_path, final_segments)
        if progress_callback:
            progress_callback(0.82)
        if settings["use_ai"]:
            notify(status_callback, "Creating AI notes...")
            export_ai_notes(job_folder, base_name, final_segments, settings["ollama_model"])
        if progress_callback:
            progress_callback(0.92)
        create_delivery_readme(job_folder, settings.get("client_name", "General"), settings.get("delivery_preset", "Meeting"))
        notify(status_callback, "Organizing client-ready folder...")
        organized_output = organize_job_output(job_folder=job_folder, base_name=base_name, client_name=settings.get("client_name", "General"))
        if progress_callback:
            progress_callback(0.96)
        if not settings["keep_wav"] and os.path.exists(clean_wav):
            os.remove(clean_wav)
        shutil.move(input_file, unique_path("completed", filename))
        status = "completed"
        notify(status_callback, f"COMPLETED: {filename}")
        notify(status_callback, f"Client-ready folder: {organized_output.get('client_ready_folder') if organized_output else job_folder}")
        if progress_callback:
            progress_callback(1.0)
    except Exception as e:
        error = str(e)
        notify(status_callback, f"FAILED: {filename}")
        notify(status_callback, error)
        save_error_report(filename, settings, error)
        try:
            shutil.move(input_file, unique_path("failed", filename))
        except Exception:
            pass
    write_history({"date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "filename": filename, "status": status, "client": settings["client_name"], "preset": settings["preset"], "model": settings["model"], "device": device_label, "duration": format_time_txt(duration), "output_folder": job_folder, "error": error})
    add_job(filename=filename, client=settings["client_name"], preset=settings["preset"], status=status, model=settings["model"], device=device_label, duration=format_time_txt(duration), output_path=job_folder, error=error)
    return {"status": status, "output_folder": job_folder, "client_ready_folder": organized_output.get("client_ready_folder") if organized_output else None, "error": error}
