import shutil
from pathlib import Path
from datetime import datetime

def backup_file(file_path, backup_root="backups"):
    source = Path(file_path)
    if not source.exists():
        return None

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = Path(backup_root) / stamp
    folder.mkdir(parents=True, exist_ok=True)

    destination = folder / source.name
    shutil.copy2(source, destination)
    return str(destination)

def backup_folder(folder_path, backup_root="backups"):
    source = Path(folder_path)
    if not source.exists():
        return None

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    destination = Path(backup_root) / f"{source.name}_{stamp}"
    shutil.copytree(source, destination, dirs_exist_ok=True)
    return str(destination)
