import os
import json
import urllib.request
from modules.exports import format_time_txt

def call_ollama(prompt, model_name):
    try:
        data = json.dumps({"model": model_name, "prompt": prompt, "stream": False}).encode("utf-8")
        request = urllib.request.Request("http://localhost:11434/api/generate", data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(request, timeout=1200) as response:
            result = json.loads(response.read().decode("utf-8"))
            return result.get("response", "").strip()
    except Exception as e:
        return f"AI generation failed: {e}"

def transcript_to_text(segments, max_chars=24000):
    lines = []
    for segment in segments:
        speaker = segment.get("speaker") or "Guest"
        lines.append(f"[{format_time_txt(segment['start'])}] {speaker}: {segment['text']}")
    text = "\\n".join(lines)
    if len(text) > max_chars:
        return text[:max_chars] + "\\n\\n[Transcript truncated for AI processing.]"
    return text

def export_ai_notes(job_folder, base_name, segments, model_name):
    transcript = transcript_to_text(segments)
    prompts = {
        "executive_summary": f"Create a professional executive summary.\\n\\nTranscript:\\n{transcript}",
        "action_items": f"Extract action items.\\n\\nTranscript:\\n{transcript}",
        "key_topics": f"Identify key topics with timestamps.\\n\\nTranscript:\\n{transcript}",
        "follow_up_questions": f"Generate useful follow-up questions.\\n\\nTranscript:\\n{transcript}",
        "client_email_summary": f"Write a professional follow-up email summary.\\n\\nTranscript:\\n{transcript}",
        "highlights": f"Find important highlights.\\n\\nTranscript:\\n{transcript}",
        "sentiment": f"Analyze tone and sentiment.\\n\\nTranscript:\\n{transcript}"
    }
    outputs = {}
    for name, prompt in prompts.items():
        result = call_ollama(prompt, model_name)
        path = os.path.join(job_folder, f"{base_name}_{name}.txt")
        with open(path, "w", encoding="utf-8") as file:
            file.write(result)
        outputs[name] = path
    return outputs
