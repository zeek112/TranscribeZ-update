from pathlib import Path
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import letter

def export_branded_pdf(output_path, title, client_name, project_type, segments, disclaimer=True):
    output_path = Path(output_path)
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(output_path), pagesize=letter)
    story = []
    story.append(Paragraph("<b>Transcript Delivery Package</b>", styles["Title"]))
    story.append(Spacer(1, 18))
    story.append(Paragraph(f"<b>Client / Project:</b> {client_name}", styles["BodyText"]))
    story.append(Paragraph(f"<b>Project Type:</b> {project_type}", styles["BodyText"]))
    story.append(Paragraph(f"<b>Document:</b> {title}", styles["BodyText"]))
    story.append(Spacer(1, 18))
    if disclaimer:
        story.append(Paragraph("Note: This transcript was AI-assisted and should be reviewed before publishing, legal use, or official recordkeeping.", styles["Italic"]))
    story.append(PageBreak())
    story.append(Paragraph("<b>Transcript</b>", styles["Heading1"]))
    story.append(Spacer(1, 10))
    for seg in segments:
        speaker = seg.get("speaker") or "Guest"
        text = (seg.get("text") or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        start = int(seg.get("start", 0))
        timestamp = f"{start//60:02d}:{start%60:02d}"
        story.append(Paragraph(f"<b>[{timestamp}] {speaker}:</b> {text}", styles["BodyText"]))
        story.append(Spacer(1, 6))
    doc.build(story)
    return str(output_path)
