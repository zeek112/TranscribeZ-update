import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path("history/jobs.db")

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT,
            filename TEXT,
            client TEXT,
            preset TEXT,
            status TEXT,
            model TEXT,
            device TEXT,
            duration TEXT,
            output_path TEXT,
            error TEXT
        )
    """)
    conn.commit()
    conn.close()

def add_job(filename, client, preset, status, model="", device="", duration="", output_path="", error=""):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO jobs
        (created_at, filename, client, preset, status, model, device, duration, output_path, error)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), filename, client, preset, status, model, device, duration, output_path, error)
    )
    conn.commit()
    conn.close()
