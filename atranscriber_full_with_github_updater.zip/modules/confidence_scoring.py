def score_transcript_segments(segments):
    """
    Simple local scoring heuristic. Faster-whisper segment confidence may not always be available,
    so this flags transcript areas likely needing review.
    """
    flagged = []
    total = len(segments)
    if total == 0:
        return {"score": 0, "flagged": []}

    for i, seg in enumerate(segments):
        text = seg.get("text", "").strip()
        reason = []

        if len(text) < 3:
            reason.append("Very short segment")
        if "[inaudible]" in text.lower() or "inaudible" in text.lower():
            reason.append("Possible inaudible section")
        if text.endswith("..."):
            reason.append("Trailing/uncertain phrase")
        if len(text.split()) > 60:
            reason.append("Long segment; may need review")

        if reason:
            flagged.append({
                "index": i + 1,
                "start": seg.get("start"),
                "end": seg.get("end"),
                "speaker": seg.get("speaker"),
                "text": text,
                "reason": "; ".join(reason)
            })

    penalty = min(60, len(flagged) * 5)
    score = max(40, 100 - penalty)

    return {
        "score": score,
        "flagged": flagged
    }

def write_confidence_report(path, segments):
    result = score_transcript_segments(segments)
    with open(path, "w", encoding="utf-8") as f:
        f.write("Transcript Confidence Review\n")
        f.write("============================\n\n")
        f.write(f"Estimated confidence score: {result['score']}/100\n")
        f.write(f"Flagged sections: {len(result['flagged'])}\n\n")
        for item in result["flagged"]:
            f.write(f"Segment {item['index']} | {item['speaker']} | {item['start']} - {item['end']}\n")
            f.write(f"Reason: {item['reason']}\n")
            f.write(f"Text: {item['text']}\n\n")
    return result
