import json
from pathlib import Path

CHANNEL_FILE = Path("update_channel.json")

DEFAULT = {
    "channel": "Stable",
    "description": "Stable is recommended for customer work."
}

def load_channel():
    if not CHANNEL_FILE.exists():
        return DEFAULT.copy()
    try:
        data = json.loads(CHANNEL_FILE.read_text(encoding="utf-8"))
        merged = DEFAULT.copy()
        merged.update(data)
        return merged
    except Exception:
        return DEFAULT.copy()

def save_channel(channel):
    descriptions = {
        "Stable": "Stable is recommended for customer work.",
        "Beta": "Beta gets newer features after basic testing.",
        "Experimental": "Experimental may break and is only for testing."
    }
    data = {"channel": channel, "description": descriptions.get(channel, "")}
    CHANNEL_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
    return data
