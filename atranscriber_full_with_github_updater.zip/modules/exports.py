import json
from docx import Document
from docx.shared import Inches

def format_time_txt(seconds):
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"

def format_time_srt(seconds):
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds - int(seconds)) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

def format_time_vtt(seconds):
    return format_time_srt(seconds).replace(",", ".")

def export_txt(path, segments):
    with open(path, "w", encoding="utf-8") as file:
        for segment in segments:
            speaker = segment.get("speaker") or "Guest"
            file.write(f"[{format_time_txt(segment['start'])} - {format_time_txt(segment['end'])}] {speaker}: {segment['text']}\\n")

def export_srt(path, segments):
    with open(path, "w", encoding="utf-8") as file:
        for index, segment in enumerate(segments, start=1):
            speaker = segment.get("speaker") or "Guest"
            file.write(f"{index}\\n")
            file.write(f"{format_time_srt(segment['start'])} --> {format_time_srt(segment['end'])}\\n")
            file.write(f"{speaker}: {segment['text']}\\n\\n")

def export_vtt(path, segments):
    with open(path, "w", encoding="utf-8") as file:
        file.write("WEBVTT\\n\\n")
        for segment in segments:
            speaker = segment.get("speaker") or "Guest"
            file.write(f"{format_time_vtt(segment['start'])} --> {format_time_vtt(segment['end'])}\\n")
            file.write(f"{speaker}: {segment['text']}\\n\\n")

def export_json(path, segments):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(segments, file, indent=4, ensure_ascii=False)

def export_docx(path, title, segments, template="clean"):
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)
    document.add_heading(title, level=1)
    document.add_heading("Transcript", level=2)
    for segment in segments:
        speaker = segment.get("speaker") or "Guest"
        paragraph = document.add_paragraph()
        run = paragraph.add_run(f"[{format_time_txt(segment['start'])}] {speaker}: ")
        run.bold = True
        paragraph.add_run(segment["text"])
    document.save(path)

def quality_report(path, original_file, segments, duration):
    score = 100
    warnings = []
    if duration <= 0:
        score -= 30
        warnings.append("Could not read media duration.")
    if len(segments) < 5:
        score -= 25
        warnings.append("Very little speech detected.")
    speaker_count = len(set(s.get("speaker", "Guest") for s in segments))
    if speaker_count == 1:
        warnings.append("Only one speaker label detected.")
    score = max(score, 0)
    with open(path, "w", encoding="utf-8") as file:
        file.write("QUALITY REPORT\\n")
        file.write("==============\\n\\n")
        file.write(f"File: {original_file}\\n")
        file.write(f"Duration: {format_time_txt(duration)}\\n")
        file.write(f"Segments: {len(segments)}\\n")
        file.write(f"Detected speakers: {speaker_count}\\n")
        file.write(f"Estimated transcript quality score: {score}/100\\n\\n")
        file.write("Warnings / Notes:\\n")
        if warnings:
            for warning in warnings:
                file.write(f"- {warning}\\n")
        else:
            file.write("- No major quality issues detected.\\n")
