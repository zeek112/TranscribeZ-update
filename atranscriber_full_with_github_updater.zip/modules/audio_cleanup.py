import subprocess

def clean_audio(input_file, output_file):
    command = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(input_file),
        "-af", "highpass=f=100,lowpass=f=12000,loudnorm",
        "-ar", "16000",
        "-ac", "1",
        str(output_file)
    ]
    result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    return output_file
