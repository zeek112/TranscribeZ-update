import os
import csv
import traceback
from datetime import datetime

HISTORY_FILE = os.path.join("history", "job_history.csv")

def ensure_folders(folders):
    for folder in folders:
        os.makedirs(folder, exist_ok=True)

def write_history(row):
    os.makedirs("history", exist_ok=True)
    exists = os.path.exists(HISTORY_FILE)
    fields = ["date", "filename", "status", "client", "preset", "model", "device", "duration", "output_folder", "error"]
    with open(HISTORY_FILE, "a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        if not exists:
            writer.writeheader()
        writer.writerow(row)

def save_error_report(filename, settings, error):
    os.makedirs("logs", exist_ok=True)
    path = os.path.join("logs", f"error_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
    with open(path, "w", encoding="utf-8") as file:
        file.write("ERROR REPORT\\n")
        file.write("============\\n\\n")
        file.write(f"File: {filename}\\n")
        file.write(f"Error: {error}\\n\\n")
        file.write("Settings:\\n")
        for key, value in settings.items():
            file.write(f"{key}: {value}\\n")
        file.write("\\nTraceback:\\n")
        file.write(traceback.format_exc())
    return path
