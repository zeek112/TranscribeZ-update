from pathlib import Path
from modules.exports import format_time_txt

def generate_chapters_from_segments(segments, max_chapters=12):
    if not segments:
        return []
    total = len(segments)
    step = max(1, total // max_chapters)
    chapters = []
    for i in range(0, total, step):
        seg = segments[i]
        text = seg.get("text", "").strip()
        label = " ".join(text.split()[:8]) or f"Section {len(chapters)+1}"
        chapters.append({"time": format_time_txt(seg.get("start", 0)), "title": label[:70]})
        if len(chapters) >= max_chapters:
            break
    return chapters

def export_chapters(path, segments):
    chapters = generate_chapters_from_segments(segments)
    with open(path, "w", encoding="utf-8") as f:
        f.write("Chapters / Timestamped Sections\n")
        f.write("===============================\n\n")
        for chapter in chapters:
            f.write(f"{chapter['time']} - {chapter['title']}\n")
    return chapters
