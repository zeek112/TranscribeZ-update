import zipfile
from pathlib import Path
from datetime import datetime

def create_fiverr_delivery_zip(job_folder, package_root="client_packages"):
    job_folder = Path(job_folder)
    if not job_folder.exists():
        return None
    Path(package_root).mkdir(parents=True, exist_ok=True)
    zip_path = Path(package_root) / f"{job_folder.name}_Fiverr_Delivery_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    preferred = ["00_CLIENT_DELIVERY_GUIDE.txt", "00_READ_ME_FIRST.txt", "01_Client_Ready", "03_Captions", "04_AI_Notes", "05_Reports", "07_Reviewed_Transcript"]
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for item_name in preferred:
            item = job_folder / item_name
            if item.exists():
                if item.is_file():
                    z.write(item, item.relative_to(job_folder))
                else:
                    for file in item.rglob("*"):
                        if file.is_file():
                            z.write(file, file.relative_to(job_folder))
    return str(zip_path)
