import json
import urllib.request
from pathlib import Path

UPDATE_FILE = Path("update_channel.json")
VERSION_FILE = Path("VERSION_MANIFEST.json")


def load_json(path, default=None):
    if default is None:
        default = {}
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def get_current_version():
    data = load_json(VERSION_FILE, {})
    return data.get("app_version", "0.0.0")


def normalize_version(version):
    parts = []
    for piece in str(version).replace("-", ".").split("."):
        try:
            parts.append(int(piece))
        except Exception:
            parts.append(0)
    return parts


def is_newer_version(latest, current):
    return normalize_version(latest) > normalize_version(current)


def check_for_updates():
    config = load_json(UPDATE_FILE, {})
    version_url = config.get("version_url")

    if not version_url:
        return {
            "success": False,
            "error": "No version URL configured in update_channel.json."
        }

    try:
        with urllib.request.urlopen(version_url, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))

        latest = data.get("latest_version", "0.0.0")
        current = get_current_version()

        return {
            "success": True,
            "current_version": current,
            "latest_version": latest,
            "update_available": is_newer_version(latest, current),
            "download_url": data.get("download_url", ""),
            "notes": data.get("notes", ""),
            "channel": data.get("channel", "stable")
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
