def detect_gpu(use_gpu):
    if not use_gpu:
        return "cpu", "int8"
    try:
        import torch
        if torch.cuda.is_available():
            print(f"GPU detected: {torch.cuda.get_device_name(0)}")
            return "cuda", "float16"
    except Exception:
        pass
    print("GPU requested, but CUDA was not detected. Using CPU.")
    return "cpu", "int8"
