from tqdm import tqdm

DIARIZATION_MODEL = "pyannote/speaker-diarization-community-1"

def run_diarization(audio_file):
    from pyannote.audio import Pipeline
    pipeline = Pipeline.from_pretrained(DIARIZATION_MODEL)
    diarization = pipeline(audio_file)
    return extract_speaker_segments(diarization)

def extract_speaker_segments(diarization):
    speaker_segments = []
    if hasattr(diarization, "itertracks"):
        tracks = list(diarization.itertracks(yield_label=True))
        for turn, _, speaker in tqdm(tracks, desc="Processing speakers", unit="speaker", ncols=100):
            speaker_segments.append({"start": float(turn.start), "end": float(turn.end), "speaker": str(speaker)})
    return speaker_segments

def best_speaker(start, end, speaker_segments):
    best = None
    best_overlap = 0
    for speaker_segment in speaker_segments:
        overlap_start = max(start, speaker_segment["start"])
        overlap_end = min(end, speaker_segment["end"])
        overlap = max(0, overlap_end - overlap_start)
        if overlap > best_overlap:
            best_overlap = overlap
            best = speaker_segment["speaker"]
    return best

def auto_rename_speakers(segments):
    speaker_map = {}
    counter = 0
    for segment in segments:
        speaker = segment.get("speaker")
        if not speaker:
            continue
        if speaker not in speaker_map:
            speaker_map[speaker] = "Guest" if counter == 0 else f"Guest {counter}"
            counter += 1
        segment["speaker"] = speaker_map[speaker]
    return segments, speaker_map

def speaker_name_editor(segments, speaker_map):
    return segments
