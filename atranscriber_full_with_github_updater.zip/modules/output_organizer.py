import shutil
from pathlib import Path

def safe_move_file(source_path, destination_folder):
    source = Path(source_path)
    if not source.exists():
        return None
    destination_folder = Path(destination_folder)
    destination_folder.mkdir(parents=True, exist_ok=True)
    destination = destination_folder / source.name
    counter = 1
    while destination.exists():
        destination = destination_folder / f"{source.stem}_{counter}{source.suffix}"
        counter += 1
    shutil.move(str(source), str(destination))
    return destination

def create_readme(job_folder, base_name, client_name):
    readme_path = Path(job_folder) / "00_READ_ME_FIRST.txt"
    content = f"""Client-Ready Transcription Package
==================================

Client / Project:
{client_name}

File:
{base_name}

Recommended workflow:
1. Open 01_Client_Ready.
2. Review DOCX or PDF.
3. Review client email summary.
4. Send approved files to client.

Folder guide:
01_Client_Ready - main deliverables
02_Working_Files - TXT and JSON
03_Captions - SRT and VTT
04_AI_Notes - summaries and notes
05_Reports - quality report
"""
    readme_path.write_text(content, encoding="utf-8")
    return readme_path

def organize_job_output(job_folder, base_name, client_name="General"):
    job_folder = Path(job_folder)
    folders = {
        "client_ready": job_folder / "01_Client_Ready",
        "working": job_folder / "02_Working_Files",
        "captions": job_folder / "03_Captions",
        "ai_notes": job_folder / "04_AI_Notes",
        "reports": job_folder / "05_Reports",
    }
    for folder in folders.values():
        folder.mkdir(parents=True, exist_ok=True)
    create_readme(job_folder, base_name, client_name)
    for filename in [f"{base_name}_transcript.docx", f"{base_name}_transcript.pdf",
        f"{base_name}_branded_transcript.pdf",
        f"{base_name}_chapters.txt", f"{base_name}_client_email_summary.txt"]:
        safe_move_file(job_folder / filename, folders["client_ready"])
    for filename in [f"{base_name}_transcript.txt", f"{base_name}.json"]:
        safe_move_file(job_folder / filename, folders["working"])
    for filename in [f"{base_name}.srt", f"{base_name}.vtt"]:
        safe_move_file(job_folder / filename, folders["captions"])
    for filename in [f"{base_name}_quality_report.txt", f"{base_name}_confidence_review.txt"]:
        safe_move_file(job_folder / filename, folders["reports"])
    for suffix in ["executive_summary", "action_items", "key_topics", "follow_up_questions", "highlights", "sentiment"]:
        safe_move_file(job_folder / f"{base_name}_{suffix}.txt", folders["ai_notes"])
    return {
        "job_folder": str(job_folder),
        "client_ready_folder": str(folders["client_ready"]),
    }
