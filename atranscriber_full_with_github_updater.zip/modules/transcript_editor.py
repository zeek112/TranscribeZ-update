import tkinter as tk
from tkinter.scrolledtext import ScrolledText

class TranscriptEditor(tk.Toplevel):
    def __init__(self, parent, transcript_text=""):
        super().__init__(parent)
        self.title("Transcript Editor")
        self.geometry("900x700")
        self.editor = ScrolledText(self, wrap="word")
        self.editor.pack(fill="both", expand=True, padx=10, pady=10)
        self.editor.insert("1.0", transcript_text)

    def get_text(self):
        return self.editor.get("1.0", "end").strip()
