import os
import glob

SUPPORTED_FILES = ("*.mp3", "*.wav", "*.m4a", "*.mp4", "*.mov")

def find_media_files(input_folder):
    files = []
    for pattern in SUPPORTED_FILES:
        files.extend(glob.glob(os.path.join(input_folder, pattern)))
    return files

def print_queue(files):
    print("\\nQueue")
    print("=====")
    for file in files:
        print(f"WAITING: {os.path.basename(file)}")
