import zipfile
from pathlib import Path
from datetime import datetime

def create_client_package(client_ready_folder, package_root="client_packages"):
    folder = Path(client_ready_folder)
    if not folder.exists():
        return None

    Path(package_root).mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"{folder.parent.name}_client_package_{stamp}.zip"
    zip_path = Path(package_root) / zip_name

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for file in folder.rglob("*"):
            if file.is_file():
                z.write(file, file.relative_to(folder))

    return str(zip_path)
