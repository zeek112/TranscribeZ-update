from collections import deque

class BatchQueue:
    def __init__(self):
        self.items = deque()
        self.completed = []
        self.failed = []
        self.paused = False

    def add(self, item):
        self.items.append(item)

    def clear(self):
        self.items.clear()
        self.completed.clear()
        self.failed.clear()

    def next(self):
        if self.paused or not self.items:
            return None
        return self.items.popleft()

    def mark_completed(self, item):
        self.completed.append(item)

    def mark_failed(self, item):
        self.failed.append(item)

    def pause(self):
        self.paused = True

    def resume(self):
        self.paused = False
