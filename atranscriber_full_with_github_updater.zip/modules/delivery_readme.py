from pathlib import Path

def create_delivery_readme(job_folder, client_name, project_type):
    path = Path(job_folder) / "00_CLIENT_DELIVERY_GUIDE.txt"
    content = f"""Client Delivery Guide
=====================

Client / Project:
{client_name}

Project Type:
{project_type}

Recommended delivery folder:
01_Client_Ready

Suggested client files:
- Final transcript DOCX
- Final transcript PDF
- Client email summary
- Chapters, if included
- Captions, if requested

Review folders:
02_Working_Files
03_Captions
04_AI_Notes
05_Reports
06_Original_Transcript
07_Reviewed_Transcript

Important:
AI-assisted transcripts should be reviewed before publishing, legal use, or official business records.
"""
    path.write_text(content, encoding="utf-8")
    return str(path)
