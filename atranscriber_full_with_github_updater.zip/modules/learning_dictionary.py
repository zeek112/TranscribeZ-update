import json
from pathlib import Path
from datetime import datetime

DICT_FILE = Path("learning_dictionary.json")

def load_dictionary():
    if not DICT_FILE.exists():
        return {"rules": []}
    try:
        return json.loads(DICT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"rules": []}

def save_dictionary(data):
    DICT_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")

def add_rule(original, corrected, client="Global"):
    data = load_dictionary()
    rules = data.get("rules", [])

    for rule in rules:
        if rule["original"].lower() == original.lower() and rule.get("client", "Global") == client:
            rule["corrected"] = corrected
            rule["approvals"] = rule.get("approvals", 0) + 1
            rule["last_used"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            save_dictionary(data)
            return rule

    rule = {
        "original": original,
        "corrected": corrected,
        "client": client,
        "approvals": 1,
        "denials": 0,
        "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "last_used": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    rules.append(rule)
    data["rules"] = rules
    save_dictionary(data)
    return rule

def apply_rules_to_text(text, client="Global"):
    data = load_dictionary()
    for rule in data.get("rules", []):
        if rule.get("client", "Global") in ["Global", client]:
            text = text.replace(rule["original"], rule["corrected"])
    return text

def dictionary_text():
    data = load_dictionary()
    lines = ["Learning Dictionary", "===================", ""]
    for rule in data.get("rules", []):
        lines.append(f"{rule.get('client', 'Global')}: {rule['original']} -> {rule['corrected']} | approvals: {rule.get('approvals', 0)}")
    if len(lines) == 3:
        lines.append("No rules saved yet.")
    return "\n".join(lines)
