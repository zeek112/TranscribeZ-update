from gui_app import ATranscriberGUI

if __name__ == "__main__":
    app = ATranscriberGUI()
    app.mainloop()
