@echo off
setlocal
title TranscribeZ Windows Setup

echo ============================================
echo TranscribeZ Windows Setup
echo ============================================
echo.
echo Recommended: Python 3.11 or 3.12 64-bit
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python and check "Add python.exe to PATH".
    pause
    exit /b 1
)

python --version

echo.
echo Creating virtual environment...
python -m venv venv
if errorlevel 1 (
    echo ERROR: Could not create venv.
    pause
    exit /b 1
)

echo.
echo Activating virtual environment...
call venv\Scripts\activate.bat

echo.
echo Upgrading pip...
python -m pip install --upgrade pip setuptools wheel

echo.
echo Installing pinned requirements...
pip install -r requirements.txt

echo.
choice /M "Install FFmpeg, Java, and Ollama using winget if available"
if errorlevel 2 goto skip_tools

where winget >nul 2>nul
if errorlevel 1 (
    echo winget was not found. Install FFmpeg, Java, and Ollama manually.
    goto skip_tools
)

winget install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements
winget install --id EclipseAdoptium.Temurin.21.JDK -e --accept-package-agreements --accept-source-agreements
winget install --id Ollama.Ollama -e --accept-package-agreements --accept-source-agreements

:skip_tools

echo.
choice /M "Install NVIDIA RTX/CUDA PyTorch support"
if errorlevel 2 goto skip_cuda
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

:skip_cuda

echo.
choice /M "Pull Ollama llama3.2 model now"
if errorlevel 2 goto skip_ollama
ollama pull llama3.2

:skip_ollama

echo.
echo Running health check...
python windows_health_check.py

echo.
echo Setup complete.
echo Start with:
echo run_TranscribeZ.bat
echo.
pause
endlocal
