TranscribeZ Full GUI Project
=============================

This is a full project ZIP with the expanded GUI options included.

Included GUI options:
---------------------
- Add Files
- Add Folder
- Open Input
- Open Output
- Client / Project name
- Presets
- Language
- Ollama model
- AI Notes checkbox
- Speaker Labels checkbox
- Grammar Cleanup checkbox
- GPU Mode checkbox
- Speaker name fields
- Timer / elapsed time
- ETA estimate
- Progress percent
- Quit button
- Open Last Output button
- Open output folder when done
- Close app when done
- Clear selected files when done
- Transcript editor button
- Client-ready output folder organization

Mac setup:
----------
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

If tkinter fails:
-----------------
brew install python-tk
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

Run:
----
python3 gui_app.py

Windows setup:
--------------
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python gui_app.py

System tools recommended:
-------------------------
- FFmpeg
- Java
- Ollama

For Ollama AI notes:
--------------------
ollama pull llama3.2

For speaker diarization:
------------------------
hf auth login

Then accept:
https://huggingface.co/pyannote/speaker-diarization-community-1
https://huggingface.co/pyannote/segmentation-3.0
