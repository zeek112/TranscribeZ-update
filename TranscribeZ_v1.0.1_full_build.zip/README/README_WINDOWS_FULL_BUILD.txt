TranscribeZ Windows Full Ready Build
====================================

This is a full Windows project package, not a patch.

Quick setup:
------------
1. Extract this ZIP.
2. Double-click:

   WINDOWS_SETUP\setup_windows.bat

3. After setup, double-click:

   run_TranscribeZ.bat

Included:
---------
- Full app project
- GUI
- modules folder
- pinned requirements.txt
- VERSION_MANIFEST.json
- Windows setup script
- Windows run script
- Windows health check
- output/input/completed/failed/log folders

External tools:
---------------
The setup script can install these using winget when available:
- FFmpeg
- Java JDK
- Ollama

Optional:
---------
- NVIDIA RTX/CUDA PyTorch support
- Ollama llama3.2 model

Recommended:
------------
- Windows 10/11 64-bit
- Python 3.11.x or 3.12.x 64-bit

Important:
----------
Large system installers and AI model weights are not bundled directly in this ZIP.
The setup script downloads/installs them where possible.
